
function loaded() {
	  $('.panel-sliding-rw, .panel-tutorial-rw, .panel-scrolling-rw').each(function (index) {
	      new iScroll($(this).attr('id'),{
	snap: true});
	   });
	  $(document).on('swipeleft swiperight', '.panel-sliding-rw, .panel-tutorial-rw, .panel-scrolling-rw', function(event) {
		 event.stopPropagation();
		 event.preventDefault();
		});
  	//document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);
	//document.addEventListener('DOMContentLoaded', loaded, false);
}

$(document).ready(function() {
	setTimeout(function(){loaded()},5);
});
